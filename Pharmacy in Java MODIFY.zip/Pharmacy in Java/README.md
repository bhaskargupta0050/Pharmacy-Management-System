# MedicalManagementSystem
A Java based application for handling transactions in a medical store 
