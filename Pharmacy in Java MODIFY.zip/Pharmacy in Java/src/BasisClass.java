/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Sunitha
 */
public class BasisClass {
public static int manu_id,itemcount,S_no,customerid,customer_purchases,med_code;
public static  StringBuffer id=new StringBuffer();
public static  StringBuffer pwd=new StringBuffer();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }

}
